MINI Android project — OPPO A78 5G / Android 14 target

IMPORTANT HONEST NOTE:
This is an Android installable starter app project, not a compiled APK. The current chat UI and native microphone-to-text bridge are included. Real AI model/service is NOT connected, so replies clearly say this is a starter build. I have not claimed otherwise.

APK BUILD (GitHub Actions, phone se bhi ho sakta hai):
1. GitHub account mein sign in karein.
2. New repository banayein, e.g. mini-android.
3. Is ZIP ke andar ke saare files repository ke root mein upload karein. Hidden .github folder bhi upload hona chahiye.
4. Repository ke Actions tab mein "Build MINI APK" workflow kholein.
5. "Run workflow" dabayein.
6. Build complete hone par workflow run ke Artifacts section se MINI-debug-apk download karein.
7. ZIP artifact extract karein. app-debug.apk file par tap karke install karein. Android agar permission mange to browser/file manager ke liye Install unknown apps allow karein. Sirf apne banaye APK par ye karein.

TECH:
- Kotlin Android WebView app
- minSdk 23, target/compile SDK 35
- Microphone permission and Android speech recognition
- Debug APK is unsigned release-wise; debug APK is signed with debug key and installable for testing.
- Does NOT include cloud AI or offline LLM. AI connection needs a chosen service/backend; no API key or billing configured.
